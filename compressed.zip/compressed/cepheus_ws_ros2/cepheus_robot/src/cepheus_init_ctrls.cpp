#include <controller_manager/controller_manager.h>
#include <std_msgs/Float64.h>
#include <std_msgs/msg/string.hpp>
#include <std_msgs/Bool.h>

#include "cepheus_hardware.h"
#include "cepheus_ctrl.h"


const int MSG_NUM = 100;

extern bool standard_controllers_started;
extern bool standard_controllers_started;
extern bool left_shoulder_ctrl_started;
extern bool left_elbow_ctrl_started;
extern bool right_shoulder_ctrl_started;
extern bool right_elbow_ctrl_started;

void ctlNodeReport(const std_msgs::msg::StringConstPtr &msg){

	if(standard_controllers_started &&
		left_shoulder_ctrl_started &&
		left_elbow_ctrl_started &&
		right_elbow_ctrl_started &&
		right_shoulder_ctrl_started)
		return;

	if(!standard_controllers_started && (msg->data).compare("STANDARD_CTRLS_OK") == 0){
		standard_controllers_started = true;
		//ROS_WARN("STARTEEEEDD");
	}

	if(standard_controllers_started && (msg->data).compare(std::string(RESPONSE_LEFT_ELBOW))==0){
		left_elbow_ctrl_started = true;
	}

	if(standard_controllers_started && left_elbow_ctrl_started && (msg->data).compare(std::string(RESPONSE_LEFT_SHOULDER))==0){
		left_shoulder_ctrl_started = true;
	}

	if(standard_controllers_started && (msg->data).compare(std::string(RESPONSE_RIGHT_ELBOW))==0){
		right_elbow_ctrl_started = true;
	}

	if(standard_controllers_started && right_elbow_ctrl_started && (msg->data).compare(std::string(RESPONSE_RIGHT_SHOULDER))==0){
		right_shoulder_ctrl_started = true;
	}

}


void start_standard_controllers(rclcpp::NodeHandle& nh, controller_manager::ControllerManager& cm, rclcpp::Rate& loop_rate){

	std::shared_ptr<rclcpp::Publisher> ctl_pub = nh.advertise<std_msgs::msg::String>("load_start_controllers", 10);
	std::shared_ptr<rclcpp::Subscription<unknown_template>> ctl_sub = nh.subscribe<std_msgs::msg::String>("load_start_controllers_response", 10, &ctlNodeReport);


	std_msgs::msg::Float64 set_point_msg;

	//IN ORDER TO PUBLISH THE MESSAGE MORE THAN ONE TIME
	int count = 0 ;
	std::shared_ptr<std_msgs::msg::String> msg;
	msg.data = "START_STANDARD_CTRLS";
	while (count < MSG_NUM) {

		ctl_pub.publish(msg);

		loop_rate.sleep();
		++count;
	}


	ROS_WARN("ORDER TO START STANDARD CTLS!");

	rclcpp::AsyncSpinner init_spinner(2);
	init_spinner.start();


	rclcpp::Time update_time = rclcpp::Time::now();
	rclcpp::Time prev_time = update_time;

	while(!standard_controllers_started)
	{
		std::chrono::duration time_step = update_time - prev_time;
		prev_time = update_time;

		cm.update(update_time, time_step);

		loop_rate.sleep();
	}
	init_spinner.stop();

	ROS_WARN("STANDARD CONTROLLERS HAVE STARTED!");

}

// 2020 keep it simple -- start //

void init_left_elbow_and_start_controller(rclcpp::Node& nh,
										controller_manager::ControllerManager& cm,
										CepheusHW& robot,
										rclcpp::Publisher left_elbow_pub,
										rclcpp::Rate& loop_rate)
{

	std::shared_ptr<rclcpp::Publisher> ctl_pub = nh.advertise<std_msgs::msg::String>("load_start_controllers", 10);
	std::shared_ptr<rclcpp::Subscription<unknown_template>> ctl_sub = nh.subscribe<std_msgs::msg::String>("load_start_controllers_response", 10, &ctlNodeReport);
	//rclcpp::Publisher go_to_zero_service = nh.advertise<std_msgs::msg::Bool>("left_elbow_go_to",1);

	std::shared_ptr<std_msgs::msg::String> msg;
	//std_msgs::msg::Bool empty_msg;

	robot.init_left_elbow();

	msg.data = std::string(CMD_START_LEFT_ELBOW);
	//ctl_pub.publish(msg);
	//go_to_zero_service.publish(empty_msg);
}


void init_left_shoulder_and_start_controller(rclcpp::Node& nh,
										controller_manager::ControllerManager& cm,
										CepheusHW& robot,
										rclcpp::Publisher left_shoulder_pub,
										rclcpp::Rate& loop_rate)
{

	std::shared_ptr<rclcpp::Publisher> ctl_pub = nh.advertise<std_msgs::msg::String>("load_start_controllers", 10);
	std::shared_ptr<rclcpp::Subscription<unknown_template>> ctl_sub = nh.subscribe<std_msgs::msg::String>("load_start_controllers_response", 10, &ctlNodeReport);

	std::shared_ptr<std_msgs::msg::String> msg;

	robot.init_left_shoulder();

	msg.data = std::string(CMD_START_LEFT_SHOULDER);
	//ctl_pub.publish(msg);
}


void init_right_elbow_and_start_controller(rclcpp::Node& nh,
										controller_manager::ControllerManager& cm,
										CepheusHW& robot,
										rclcpp::Publisher right_elbow_pub,
										rclcpp::Rate& loop_rate)
{

	std::shared_ptr<rclcpp::Publisher> ctl_pub = nh.advertise<std_msgs::msg::String>("load_start_controllers", 10);
	std::shared_ptr<rclcpp::Subscription<unknown_template>> ctl_sub = nh.subscribe<std_msgs::msg::String>("load_start_controllers_response", 10, &ctlNodeReport);

	std::shared_ptr<std_msgs::msg::String> msg;

	robot.init_right_elbow();

	msg.data = std::string(CMD_START_RIGHT_ELBOW);
	//ctl_pub.publish(msg);
}



// 2020 keep it simple -- end //

void init_left_arm_and_start_controllers(rclcpp::Node& nh,
										controller_manager::ControllerManager& cm,
										CepheusHW& robot,
										rclcpp::Publisher left_shoulder_pub,
										rclcpp::Publisher left_elbow_pub,
										rclcpp::Rate& loop_rate)
{

	std::shared_ptr<rclcpp::Publisher> ctl_pub = nh.advertise<std_msgs::msg::String>("load_start_controllers", 10);
	std::shared_ptr<rclcpp::Subscription<unknown_template>> ctl_sub = nh.subscribe<std_msgs::msg::String>("load_start_controllers_response", 10, &ctlNodeReport);

//	std_msgs::msg::Float64 set_point_msg;

	//IN ORDER TO PUBLISH THE MESSAGE MORE THAN ONE TIME
//	int count = 0 ;
	std::shared_ptr<std_msgs::msg::String> msg;

//	rclcpp::AsyncSpinner init_spinner(2);
//	init_spinner.start();


//	rclcpp::Time update_time = rclcpp::Time::now();
//	rclcpp::Time prev_time = update_time;


	//INITIALIZE THE LEFT ELBOW
	robot.init_left_elbow();

	msg.data = std::string(CMD_START_LEFT_ELBOW);
	ctl_pub.publish(msg);

/*	count = 0;
	while (count < MSG_NUM) {

		ctl_pub.publish(msg);

		loop_rate.sleep();
		++count;
	}

*/
/*
	init_spinner.start();
	while(!left_elbow_ctrl_started)
	{
		//rclcpp::Time curr_time = rclcpp::Time::now();
		rclcpp::Duration time_step = update_time - prev_time;
		prev_time = update_time;

		robot.readEncoders(time_step);
		cm.update(update_time, time_step);

		loop_rate.sleep();
	}
	init_spinner.stop();
*/

	//INITIALIZE THE LEFT SHOULDER
//	robot.init_left_shoulder();
/*	msg.data = std::string(CMD_START_LEFT_SHOULDER);

	count = 0;
	while (count < MSG_NUM) {

		ctl_pub.publish(msg);

		loop_rate.sleep();
		++count;
	}
*/
/*
	init_spinner.start();

	while(!left_shoulder_ctrl_started)
	{
		//rclcpp::Time curr_time = rclcpp::Time::now();

		set_point_msg.data = robot.getPos(LEFT_ELBOW);

		left_elbow_pub.publish(set_point_msg);

		rclcpp::Duration time_step = update_time - prev_time;
		prev_time = update_time;

		robot.readEncoders(time_step);
		cm.update(update_time, time_step);

		loop_rate.sleep();
	}

	init_spinner.stop();
*/
	//Initialize the left finger and the wrist
	//robot.init_left_finger();
	//robot.init_left_wrist();

}


void init_right_arm_and_start_controllers(rclcpp::Node& nh,
										controller_manager::ControllerManager& cm,
										CepheusHW& robot,
										rclcpp::Publisher right_shoulder_pub,
										rclcpp::Publisher right_elbow_pub,
										rclcpp::Rate& loop_rate)
{

/*	rclcpp::Publisher ctl_pub = nh.advertise<std_msgs::msg::String>("load_start_controllers", 10);
	rclcpp::Subscriber ctl_sub = nh.subscribe<std_msgs::msg::String>("load_start_controllers_response", 10, &ctlNodeReport);

	int count = 0 ;
	std_msgs::msg::Float64 set_point_msg;
	std_msgs::msg::String msg;

	rclcpp::AsyncSpinner init_spinner(2);


	rclcpp::Time update_time = rclcpp::Time::now();
	rclcpp::Time prev_time = update_time;
*/
	//INITIALIZE THE RIGHT ELBOW
	robot.init_right_elbow();
	/*msg.data = std::string(CMD_START_RIGHT_ELBOW);
	ctl_pub.publish(msg);

	count = 0;
	while (count < MSG_NUM) {

		ctl_pub.publish(msg);

		loop_rate.sleep();
		++count;
	}

	init_spinner.start();

	while(!right_elbow_ctrl_started)
	{
		//rclcpp::Time curr_time = rclcpp::Time::now();
		rclcpp::Duration time_step = update_time - prev_time;
		prev_time = update_time;

		robot.readEncoders(time_step);
		cm.update(update_time, time_step);

		loop_rate.sleep();
	}






	init_spinner.stop();
*/
/*
	//INITIALIZE THE RIGHT SHOULDER
	//robot.init_right_shoulder();
	msg.data = std::string(CMD_START_RIGHT_SHOULDER);
	ctl_pub.publish(msg);

	count = 0;
	while (count < MSG_NUM) {

		ctl_pub.publish(msg);

		loop_rate.sleep();
		++count;
	}

	init_spinner.start();

	while(!right_shoulder_ctrl_started)
	{
		//rclcpp::Time curr_time = rclcpp::Time::now();

		set_point_msg.data = robot.getPos(RIGHT_ELBOW);

		right_elbow_pub.publish(set_point_msg);

		rclcpp::Duration time_step = update_time - prev_time;
		prev_time = update_time;

		robot.readEncoders(time_step);
		cm.update(update_time, time_step);

		loop_rate.sleep();
	}
*/
/*	init_spinner.stop();

	robot.init_right_finger();
	robot.init_right_wrist();
*/
}
